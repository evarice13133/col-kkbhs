SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `settings` VALUES('allow_teacher_registration','0');
INSERT INTO `settings` VALUES('backup_enabled','1');
INSERT INTO `settings` VALUES('backup_github_auth','ssh');
INSERT INTO `settings` VALUES('backup_github_branch','main');
INSERT INTO `settings` VALUES('backup_github_owner','evarice13133');
INSERT INTO `settings` VALUES('backup_github_repository','notesmaster-backups');
INSERT INTO `settings` VALUES('backup_git_user_email','backup-bot@notesmaster.local');
INSERT INTO `settings` VALUES('backup_git_user_name','NotesMaster Backup Bot');
INSERT INTO `settings` VALUES('backup_git_worktree','storage/backup-repository');
INSERT INTO `settings` VALUES('backup_push_enabled','1');
INSERT INTO `settings` VALUES('backup_retention_count','12');
INSERT INTO `settings` VALUES('backup_schedule_day','Sunday');
INSERT INTO `settings` VALUES('backup_schedule_time','02:00');
INSERT INTO `settings` VALUES('backup_storage_path','storage/backups');
INSERT INTO `settings` VALUES('display_school_year','2025-2026');
INSERT INTO `settings` VALUES('honor_roll_default_threshold','12');
INSERT INTO `settings` VALUES('honor_roll_threshold_class_76','14');
INSERT INTO `settings` VALUES('matricule_counter','3653');
INSERT INTO `settings` VALUES('matricule_format','{SCHOOL_CODE}-{CLASS}-MT{COUNTER}');
INSERT INTO `settings` VALUES('principal_name','EFFION OKON AKAISO');
INSERT INTO `settings` VALUES('principal_signature','');
INSERT INTO `settings` VALUES('principal_title','PRINCIPAL');
INSERT INTO `settings` VALUES('school_city','BWADIBO');
INSERT INTO `settings` VALUES('school_code','COPOBIMAT');
INSERT INTO `settings` VALUES('school_email','evaricekuete2@gmail.com');
INSERT INTO `settings` VALUES('school_fax','656963491');
INSERT INTO `settings` VALUES('school_logo','/uploads/1777926597_1777685166_logo.jpeg');
INSERT INTO `settings` VALUES('school_ministry','Ministère des Enseignements Secondaires');
INSERT INTO `settings` VALUES('school_ministry_en','Ministry of Secondary Education');
INSERT INTO `settings` VALUES('school_motto','Paix - Travail - Patrie');
INSERT INTO `settings` VALUES('school_motto_en','Peace - Work - Fatherland');
INSERT INTO `settings` VALUES('school_name','Collège Polyvalent Bilingue Marie-Thérèse');
INSERT INTO `settings` VALUES('school_phone','676792204/659099093');
INSERT INTO `settings` VALUES('school_po_box','51442');
INSERT INTO `settings` VALUES('school_republic','Republique du Cameroun');
INSERT INTO `settings` VALUES('school_republic_en','Republic of Cameroon');
INSERT INTO `settings` VALUES('school_slogan','Discipline - Travail - Succes');
INSERT INTO `settings` VALUES('school_slogan_en','Discipline - Work - Success');
INSERT INTO `settings` VALUES('school_stamp','');
INSERT INTO `settings` VALUES('school_website','https://www.istec-educations.com');
INSERT INTO `settings` VALUES('theme_admin_hero_card','#5d7894');
INSERT INTO `settings` VALUES('theme_admin_hero_end','#2f6fed');
INSERT INTO `settings` VALUES('theme_admin_hero_glow','#f4b942');
INSERT INTO `settings` VALUES('theme_admin_hero_start','#16324f');
INSERT INTO `settings` VALUES('theme_button_bg','#036305');
INSERT INTO `settings` VALUES('theme_button_text','#ffffff');
INSERT INTO `settings` VALUES('theme_glow_bg','#eef4fb');
INSERT INTO `settings` VALUES('theme_glow_text','#1c4169');
INSERT INTO `settings` VALUES('theme_login_bg_end','#02550c');
INSERT INTO `settings` VALUES('theme_login_bg_mid','#16324f');
INSERT INTO `settings` VALUES('theme_login_bg_start','#0a241b');
INSERT INTO `settings` VALUES('theme_login_bubble','#f4b942');
INSERT INTO `settings` VALUES('theme_login_button','#1f5fbf');
INSERT INTO `settings` VALUES('theme_login_panel_badge_bg','#e8f0ff');
INSERT INTO `settings` VALUES('theme_login_panel_badge_text','#1f5fbf');
INSERT INTO `settings` VALUES('theme_login_panel_bg','#ffffff');
INSERT INTO `settings` VALUES('theme_login_showcase_end','#143961');
INSERT INTO `settings` VALUES('theme_login_showcase_glow','#f4b942');
INSERT INTO `settings` VALUES('theme_login_showcase_start','#102033');
INSERT INTO `settings` VALUES('theme_navbar_bg','#00a81c');
INSERT INTO `settings` VALUES('theme_navbar_hover','#ffffff');
INSERT INTO `settings` VALUES('theme_teacher_hero_card','#5d7894');
INSERT INTO `settings` VALUES('theme_teacher_hero_end','#2f6fed');
INSERT INTO `settings` VALUES('theme_teacher_hero_glow','#f4b942');
INSERT INTO `settings` VALUES('theme_teacher_hero_start','#16324f');

DROP TABLE IF EXISTS `academic_years`;
CREATE TABLE `academic_years` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `status` enum('active','archived') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `academic_years` VALUES('1','2024-2025','0','active','2026-03-25 19:22:11');
INSERT INTO `academic_years` VALUES('2','2025-2026','1','active','2026-03-25 19:22:27');
INSERT INTO `academic_years` VALUES('3','2026-2027','0','active','2026-05-04 22:46:59');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('superadmin','admin','enseignant') NOT NULL DEFAULT 'enseignant',
  `establishment_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_establishment` (`establishment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `users` VALUES('1','Super','Administrateur','sup','sup@gmail.com','$2y$10$ERjX1gL1/2ryH4Ck0PpaO.UJx/RLvTxBBRWKoMKlF3LM3FrfFqB/q','superadmin','1','2026-04-25 16:30:48','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('26','Kuete','Evarice','evarice','evaricekuete2@gmail.com','$2y$10$JAiRzYuOd5xdvSgiGifyKOUgbCAPvbvIuBSBtcMITt1I7xxu28JXu','enseignant','1','2026-05-02 04:34:55','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('27','Effion Akon','Akaiso','effion',NULL,'$2y$10$4FFNlCdhkdfRb.6kXMj7Y.PfXAVGRyMqfhgY6xyZhp7nLvJv9zP.2','enseignant','1','2026-05-02 23:48:15','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('28','NGUIATAZUING TATCHIDJOU','Ariane Mergane','ariane',NULL,'$2y$10$kn1WeSgeyOKzmvoQNVKM4eV6njVWjuPo/UxZF3XW0hSRQdLrPfsXe','enseignant','1','2026-05-03 00:25:37','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('29','Lonfo','Derick','lonfo',NULL,'$2y$10$Xh4CoiapfFh1XYP4pKfXdutIGPU0MCqfOvRfTjgvBSLPVxn5i1RXi','enseignant','1','2026-05-03 13:57:50','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('30','Nkonlack','Orlien','orlien',NULL,'$2y$10$fHaAwOgiRsPMFtfbFLQRY.EOSvBIYk6XUrumZMXF9HgmByv1qmcC6','enseignant','1','2026-05-04 14:51:01','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('31','Toumboung','Armani','armani',NULL,'$2y$10$6GCGRtkZIuCBJTQwzx.yv.jIAijbs/Ze1XzbaseZ.LcwEynSlplUi','enseignant','1','2026-05-04 15:50:22','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('32','pogme','alain','alain',NULL,'$2y$10$x7igBNmqorTJSqCXEvlx9uw8lMhRbcJwz9H2leJjuLGo/WAsz8Ux2','enseignant','1','2026-05-05 01:56:03','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('33','Login elessa','Junior','elessa',NULL,'$2y$10$KtRfhNtjqkSr716slaXrXOhbgDjdApPfrRvqraM4z40melrDaV/6S','enseignant','1','2026-05-05 01:57:12','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('35','TIMA','Rogés','tima',NULL,'$2y$10$eDVxLS8sFXL2FOpYwv6jsOcarcfGTv5beiCjuX4WJNPozF4KYiIiC','enseignant','1','2026-05-05 03:54:48','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('37','Alida','Alida','alida',NULL,'$2y$10$dHKjzCtWwJKfahW8jvd3zO/qR23zhUCQ6j5nYfolHKHzxO3jRnvIW','enseignant','1','2026-05-05 03:58:29','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('38','leo','','leo',NULL,'$2y$10$6sA77kvbscgGxiWOFdpbwugQmTUg.CjV9In7pq/rOx2NM4DtUNxN6','enseignant','1','2026-05-08 14:29:34','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('39','Admin','Admin','admin1',NULL,'$argon2id$v=19$m=65536,t=4,p=1$dHZJSzJmUjBTSC5LVzVtdw$jUIaJF2l+xG9yXhUeHK5e93nF6MPGVLQCdJDwe0DvAU','admin','1','2026-05-11 15:26:49','2026-05-19 03:56:59');
INSERT INTO `users` VALUES('40','Admin','Andrée','andre',NULL,'$2y$10$BPqkoKI4DSfSjgOHq6p1fOfxCsQyJeq8PqngoDmNWVQz.870WIesy','admin','2','2026-05-19 04:47:35','2026-05-19 04:47:35');

DROP TABLE IF EXISTS `cycles`;
CREATE TABLE `cycles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`),
  KEY `idx_cycles_establishment` (`establishment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `cycles` VALUES('2','2nd Cycle','1','2026-03-25 20:39:23');
INSERT INTO `cycles` VALUES('3','1ere Cycle','1','2026-03-26 18:43:38');

DROP TABLE IF EXISTS `sections`;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`),
  KEY `idx_sections_establishment` (`establishment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `sections` VALUES('1','Francophone','1','2026-03-25 20:39:48');
INSERT INTO `sections` VALUES('2','Anglophone','1','2026-03-25 20:40:00');
INSERT INTO `sections` VALUES('11','Bilingue',NULL,'2026-05-27 02:50:07');

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  `code` varchar(20) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`),
  KEY `idx_departments_establishment` (`establishment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `departments` VALUES('2','Maçonnerie','1','MACO','1','2026-03-25 21:04:30');
INSERT INTO `departments` VALUES('3','Employes et Services Comptable(ESCOM)','1','ESCOM','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('4','ESG (Enseignement General)','1','ESG','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('6','Electricite (ELECT)','1','ELECT','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('7','Mecanique','1','MECA','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('8','Informatique et Reseaux (TI)','1','TI','0','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('9','Gestion','1','CG','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('10','Chaudronerie et Soudure','1','CH','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('11','Couture (COME)','1','COME','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('12','Secretariat Medical (SEME)','1','SEME','1','2026-03-26 18:47:42');
INSERT INTO `departments` VALUES('23','Couture Industrielle (IH)','1','IH','1','2026-05-06 05:41:31');
INSERT INTO `departments` VALUES('24','Metaux et Ferre(MEFE)','1','MEFE','1','2026-05-06 05:44:16');

DROP TABLE IF EXISTS `user_departments`;
CREATE TABLE `user_departments` (
  `user_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`department_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `user_departments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_departments_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `subject_classes`;
CREATE TABLE `subject_classes` (
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`subject_id`,`class_id`),
  KEY `class_id` (`class_id`),
  KEY `idx_subject_classes_establishment` (`establishment_id`),
  CONSTRAINT `subject_classes_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subject_classes_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `subject_classes` VALUES('32','13',NULL);
INSERT INTO `subject_classes` VALUES('32','14',NULL);
INSERT INTO `subject_classes` VALUES('32','15',NULL);
INSERT INTO `subject_classes` VALUES('32','16',NULL);
INSERT INTO `subject_classes` VALUES('32','20',NULL);
INSERT INTO `subject_classes` VALUES('32','22',NULL);
INSERT INTO `subject_classes` VALUES('32','23',NULL);
INSERT INTO `subject_classes` VALUES('32','76',NULL);
INSERT INTO `subject_classes` VALUES('46','12',NULL);
INSERT INTO `subject_classes` VALUES('46','20',NULL);
INSERT INTO `subject_classes` VALUES('46','21',NULL);
INSERT INTO `subject_classes` VALUES('46','24',NULL);
INSERT INTO `subject_classes` VALUES('46','25',NULL);
INSERT INTO `subject_classes` VALUES('46','76',NULL);
INSERT INTO `subject_classes` VALUES('63','76',NULL);
INSERT INTO `subject_classes` VALUES('15','13','1');
INSERT INTO `subject_classes` VALUES('15','14','1');
INSERT INTO `subject_classes` VALUES('15','15','1');
INSERT INTO `subject_classes` VALUES('15','16','1');
INSERT INTO `subject_classes` VALUES('15','23','1');
INSERT INTO `subject_classes` VALUES('16','13','1');
INSERT INTO `subject_classes` VALUES('16','14','1');
INSERT INTO `subject_classes` VALUES('16','15','1');
INSERT INTO `subject_classes` VALUES('16','16','1');
INSERT INTO `subject_classes` VALUES('16','22','1');
INSERT INTO `subject_classes` VALUES('16','23','1');
INSERT INTO `subject_classes` VALUES('17','13','1');
INSERT INTO `subject_classes` VALUES('17','14','1');
INSERT INTO `subject_classes` VALUES('17','15','1');
INSERT INTO `subject_classes` VALUES('17','16','1');
INSERT INTO `subject_classes` VALUES('17','23','1');
INSERT INTO `subject_classes` VALUES('18','13','1');
INSERT INTO `subject_classes` VALUES('18','14','1');
INSERT INTO `subject_classes` VALUES('18','15','1');
INSERT INTO `subject_classes` VALUES('18','16','1');
INSERT INTO `subject_classes` VALUES('19','22','1');
INSERT INTO `subject_classes` VALUES('19','23','1');
INSERT INTO `subject_classes` VALUES('20','13','1');
INSERT INTO `subject_classes` VALUES('20','14','1');
INSERT INTO `subject_classes` VALUES('20','15','1');
INSERT INTO `subject_classes` VALUES('20','16','1');
INSERT INTO `subject_classes` VALUES('20','22','1');
INSERT INTO `subject_classes` VALUES('20','23','1');
INSERT INTO `subject_classes` VALUES('21','13','1');
INSERT INTO `subject_classes` VALUES('21','14','1');
INSERT INTO `subject_classes` VALUES('21','15','1');
INSERT INTO `subject_classes` VALUES('21','16','1');
INSERT INTO `subject_classes` VALUES('21','22','1');
INSERT INTO `subject_classes` VALUES('21','23','1');
INSERT INTO `subject_classes` VALUES('22','13','1');
INSERT INTO `subject_classes` VALUES('22','14','1');
INSERT INTO `subject_classes` VALUES('22','15','1');
INSERT INTO `subject_classes` VALUES('22','16','1');
INSERT INTO `subject_classes` VALUES('22','22','1');
INSERT INTO `subject_classes` VALUES('22','23','1');
INSERT INTO `subject_classes` VALUES('23','13','1');
INSERT INTO `subject_classes` VALUES('23','14','1');
INSERT INTO `subject_classes` VALUES('23','15','1');
INSERT INTO `subject_classes` VALUES('23','16','1');
INSERT INTO `subject_classes` VALUES('23','22','1');
INSERT INTO `subject_classes` VALUES('23','23','1');
INSERT INTO `subject_classes` VALUES('24','13','1');
INSERT INTO `subject_classes` VALUES('24','14','1');
INSERT INTO `subject_classes` VALUES('24','15','1');
INSERT INTO `subject_classes` VALUES('24','16','1');
INSERT INTO `subject_classes` VALUES('24','22','1');
INSERT INTO `subject_classes` VALUES('24','23','1');
INSERT INTO `subject_classes` VALUES('25','13','1');
INSERT INTO `subject_classes` VALUES('25','14','1');
INSERT INTO `subject_classes` VALUES('25','15','1');
INSERT INTO `subject_classes` VALUES('25','16','1');
INSERT INTO `subject_classes` VALUES('25','22','1');
INSERT INTO `subject_classes` VALUES('25','23','1');
INSERT INTO `subject_classes` VALUES('26','13','1');
INSERT INTO `subject_classes` VALUES('26','14','1');
INSERT INTO `subject_classes` VALUES('26','15','1');
INSERT INTO `subject_classes` VALUES('26','16','1');
INSERT INTO `subject_classes` VALUES('26','22','1');
INSERT INTO `subject_classes` VALUES('26','23','1');
INSERT INTO `subject_classes` VALUES('27','1','1');
INSERT INTO `subject_classes` VALUES('28','13','1');
INSERT INTO `subject_classes` VALUES('28','14','1');
INSERT INTO `subject_classes` VALUES('28','15','1');
INSERT INTO `subject_classes` VALUES('28','16','1');
INSERT INTO `subject_classes` VALUES('28','22','1');
INSERT INTO `subject_classes` VALUES('28','23','1');
INSERT INTO `subject_classes` VALUES('29','13','1');
INSERT INTO `subject_classes` VALUES('29','14','1');
INSERT INTO `subject_classes` VALUES('29','15','1');
INSERT INTO `subject_classes` VALUES('29','16','1');
INSERT INTO `subject_classes` VALUES('29','22','1');
INSERT INTO `subject_classes` VALUES('29','23','1');
INSERT INTO `subject_classes` VALUES('30','13','1');
INSERT INTO `subject_classes` VALUES('30','14','1');
INSERT INTO `subject_classes` VALUES('30','15','1');
INSERT INTO `subject_classes` VALUES('30','16','1');
INSERT INTO `subject_classes` VALUES('30','22','1');
INSERT INTO `subject_classes` VALUES('30','23','1');
INSERT INTO `subject_classes` VALUES('31','13','1');
INSERT INTO `subject_classes` VALUES('31','14','1');
INSERT INTO `subject_classes` VALUES('31','15','1');
INSERT INTO `subject_classes` VALUES('31','16','1');
INSERT INTO `subject_classes` VALUES('31','20','1');
INSERT INTO `subject_classes` VALUES('31','22','1');
INSERT INTO `subject_classes` VALUES('31','23','1');
INSERT INTO `subject_classes` VALUES('33','12','1');
INSERT INTO `subject_classes` VALUES('34','20','1');
INSERT INTO `subject_classes` VALUES('35','25','1');
INSERT INTO `subject_classes` VALUES('36','12','1');
INSERT INTO `subject_classes` VALUES('36','24','1');
INSERT INTO `subject_classes` VALUES('37','20','1');
INSERT INTO `subject_classes` VALUES('37','25','1');
INSERT INTO `subject_classes` VALUES('38','12','1');
INSERT INTO `subject_classes` VALUES('39','20','1');
INSERT INTO `subject_classes` VALUES('39','25','1');
INSERT INTO `subject_classes` VALUES('40','12','1');
INSERT INTO `subject_classes` VALUES('41','20','1');
INSERT INTO `subject_classes` VALUES('42','25','1');
INSERT INTO `subject_classes` VALUES('43','12','1');
INSERT INTO `subject_classes` VALUES('44','12','1');
INSERT INTO `subject_classes` VALUES('44','20','1');
INSERT INTO `subject_classes` VALUES('44','21','1');
INSERT INTO `subject_classes` VALUES('44','24','1');
INSERT INTO `subject_classes` VALUES('44','25','1');
INSERT INTO `subject_classes` VALUES('45','12','1');
INSERT INTO `subject_classes` VALUES('45','20','1');
INSERT INTO `subject_classes` VALUES('45','21','1');
INSERT INTO `subject_classes` VALUES('45','24','1');
INSERT INTO `subject_classes` VALUES('45','25','1');
INSERT INTO `subject_classes` VALUES('47','20','1');
INSERT INTO `subject_classes` VALUES('47','25','1');
INSERT INTO `subject_classes` VALUES('48','20','1');
INSERT INTO `subject_classes` VALUES('49','21','1');
INSERT INTO `subject_classes` VALUES('49','24','1');
INSERT INTO `subject_classes` VALUES('49','25','1');
INSERT INTO `subject_classes` VALUES('50','12','1');
INSERT INTO `subject_classes` VALUES('50','20','1');
INSERT INTO `subject_classes` VALUES('51','12','1');
INSERT INTO `subject_classes` VALUES('51','25','1');
INSERT INTO `subject_classes` VALUES('52','12','1');
INSERT INTO `subject_classes` VALUES('52','20','1');
INSERT INTO `subject_classes` VALUES('52','21','1');
INSERT INTO `subject_classes` VALUES('52','24','1');
INSERT INTO `subject_classes` VALUES('52','25','1');
INSERT INTO `subject_classes` VALUES('53','21','1');
INSERT INTO `subject_classes` VALUES('53','24','1');
INSERT INTO `subject_classes` VALUES('54','21','1');
INSERT INTO `subject_classes` VALUES('54','24','1');
INSERT INTO `subject_classes` VALUES('55','21','1');
INSERT INTO `subject_classes` VALUES('55','24','1');
INSERT INTO `subject_classes` VALUES('56','21','1');
INSERT INTO `subject_classes` VALUES('56','24','1');
INSERT INTO `subject_classes` VALUES('57','21','1');
INSERT INTO `subject_classes` VALUES('58','21','1');
INSERT INTO `subject_classes` VALUES('59','24','1');
INSERT INTO `subject_classes` VALUES('60','21','1');
INSERT INTO `subject_classes` VALUES('60','24','1');
INSERT INTO `subject_classes` VALUES('61','21','1');
INSERT INTO `subject_classes` VALUES('61','24','1');
INSERT INTO `subject_classes` VALUES('62','2','1');

DROP TABLE IF EXISTS `teacher_assignments`;
CREATE TABLE `teacher_assignments` (
  `user_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`subject_id`,`class_id`),
  UNIQUE KEY `idx_teacher_unique_assignment` (`class_id`,`subject_id`),
  KEY `subject_id` (`subject_id`),
  KEY `idx_ta_user` (`user_id`),
  KEY `idx_teacher_assignments_establishment` (`establishment_id`),
  CONSTRAINT `teacher_assignments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teacher_assignments_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teacher_assignments_ibfk_3` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `teacher_assignments` VALUES('35','32','76',NULL);
INSERT INTO `teacher_assignments` VALUES('37','46','76',NULL);
INSERT INTO `teacher_assignments` VALUES('26','16','15','1');
INSERT INTO `teacher_assignments` VALUES('26','16','16','1');
INSERT INTO `teacher_assignments` VALUES('26','16','22','1');
INSERT INTO `teacher_assignments` VALUES('26','16','23','1');
INSERT INTO `teacher_assignments` VALUES('26','56','24','1');
INSERT INTO `teacher_assignments` VALUES('29','39','20','1');
INSERT INTO `teacher_assignments` VALUES('37','20','14','1');
INSERT INTO `teacher_assignments` VALUES('37','20','15','1');
INSERT INTO `teacher_assignments` VALUES('37','45','20','1');
INSERT INTO `teacher_assignments` VALUES('38','34','20','1');
INSERT INTO `teacher_assignments` VALUES('38','35','25','1');

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `lieu_naissance` varchar(150) DEFAULT NULL,
  `is_redoublant` tinyint(1) NOT NULL DEFAULT 0,
  `academic_year_id` int(11) DEFAULT NULL,
  `is_withdrawn` tinyint(1) NOT NULL DEFAULT 0,
  `email` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `class_id` int(11) DEFAULT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  `sexe` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_students_email` (`email`),
  KEY `idx_students_class` (`class_id`),
  KEY `idx_students_establishment` (`establishment_id`),
  KEY `fk_students_academic_year` (`academic_year_id`),
  CONSTRAINT `fk_students_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `students_ibfk_3` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `students` VALUES('1','ADAMOU CLOVIS','Synfrad','2013-02-01','bwadibo','0','1','0','cpbmt-5EME-MT003644','2026-05-02 03:37:25','5','1','M');
INSERT INTO `students` VALUES('2','NGALANI NGALAHA','Christ Arlann','2026-05-03','Bwadibo','0','1','0','COPOBIMAT-6EME-MT003645','2026-05-03 09:40:38','1','1','M');
INSERT INTO `students` VALUES('3','LONING  ÉLÈVE','Raissa','2003-05-03','Mbouda','0','1','0','COPOBIMAT-FORM1-MT003646','2026-05-03 09:46:38','2','1','F');
INSERT INTO `students` VALUES('4','AMETOUKAM KAMGA','Jennifer',NULL,'babenga','0','1','0','COPOBIMAT-6EME-MT003647','2026-05-03 14:54:34','1','1','M');
INSERT INTO `students` VALUES('5','TATCHINDA','Franck',NULL,NULL,'0','1','0','COPOBIMAT-1EREF4-MT003648','2026-05-04 14:58:26','39','1','M');
INSERT INTO `students` VALUES('6','MELI FOFIE','HONY JOEL',NULL,NULL,'0','1','0','COPOBIMAT-TLED-MT003649','2026-05-07 01:15:36','24','1','M');
INSERT INTO `students` VALUES('7','NGALANI GALAHA','Christ',NULL,NULL,'0','1','0','COPOBIMAT-1EREC-MT003650','2026-05-08 14:33:49','20','1','M');
INSERT INTO `students` VALUES('8','TESTTES','test',NULL,NULL,'0','1','0','cpbmt-6EME-MT003644','2026-05-26 13:29:39','5',NULL,'M');
INSERT INTO `students` VALUES('20','EVARICE','Evarice','2012-05-12','Yaoundé','0','1','0','23igl000076','2026-05-26 23:29:48','20',NULL,'M');
INSERT INTO `students` VALUES('24','EVARICE','Evarice','2012-05-12','Yaoundé','0','1','0','23igl0000706','2026-05-26 23:36:13','20',NULL,'M');
INSERT INTO `students` VALUES('25','EVARICE','Evarice','2013-05-12','Yaoundé','0','1','0','23igl000077','2026-05-26 23:36:13','20',NULL,'M');
INSERT INTO `students` VALUES('26','EVARICE','Evarice','2014-05-12','Yaoundé','0','1','0','23igl000078','2026-05-26 23:36:13','20',NULL,'M');
INSERT INTO `students` VALUES('27','EVARICE','Evarice','2015-05-12','Yaoundé','0','1','0','23igl000079','2026-05-26 23:36:13','20',NULL,'M');
INSERT INTO `students` VALUES('28','ELEVE TEST','eleve test','2012-05-12','Yaoundé','0','1','0','23igl0000707','2026-05-26 23:38:33','76',NULL,'M');
INSERT INTO `students` VALUES('29','ELEVE TEST','eleve test','2012-05-12','Yaoundé','0','1','0','23igl0000708','2026-05-26 23:39:53','20',NULL,'M');
INSERT INTO `students` VALUES('30','ALBERT','test','2012-05-12','Yaoundé','0','1','0','23AMA0000709','2026-05-26 23:45:35','20',NULL,'M');
INSERT INTO `students` VALUES('31','ALBERT','test','2012-05-12','Yaoundé','0','1','0','23igl0000709','2026-05-26 23:46:19','20',NULL,'M');
INSERT INTO `students` VALUES('32','TEST','TEst',NULL,NULL,'0','1','0','COPOBIMAT-6EMEC-MT003651','2026-05-27 00:45:01','76',NULL,'M');
INSERT INTO `students` VALUES('33','TEST YEAR','year',NULL,NULL,'0','1','0','COPOBIMAT-6EME-MT003652','2026-05-28 02:25:04','1',NULL,'M');

DROP TABLE IF EXISTS `grades`;
CREATE TABLE `grades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `sequence_id` int(11) DEFAULT NULL,
  `periode` varchar(50) NOT NULL,
  `valeur` float DEFAULT NULL CHECK (`valeur` >= 0 and `valeur` <= 20),
  `appreciation` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_subject_period` (`student_id`,`subject_id`,`periode`,`academic_year_id`),
  KEY `subject_id` (`subject_id`),
  KEY `academic_year_id` (`academic_year_id`),
  KEY `idx_grades_stats` (`teacher_id`,`academic_year_id`,`subject_id`),
  KEY `sequence_id` (`sequence_id`),
  CONSTRAINT `fk_grades_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grades_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grades_ibfk_4` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL,
  CONSTRAINT `grades_ibfk_5` FOREIGN KEY (`sequence_id`) REFERENCES `sequences` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `grades` VALUES('178','6','56','26','1','1','Sequence 1','15','Bien','2026-05-08 14:21:02','2026-05-08 14:21:02');
INSERT INTO `grades` VALUES('179','6','56','26','1','2','Sequence 2','14','Bien','2026-05-08 14:21:17','2026-05-08 14:21:17');
INSERT INTO `grades` VALUES('180','7','34','38','1','1','Sequence 1','12.5','Assez Bien','2026-05-09 09:33:38','2026-05-09 09:34:07');
INSERT INTO `grades` VALUES('182','32','63','39','1','1','Sequence 1','15','Bien','2026-05-27 00:46:32','2026-05-27 00:46:32');
INSERT INTO `grades` VALUES('183','32','63','39','1','2','Sequence 2','17.5','Très Bien','2026-05-27 00:46:46','2026-05-27 00:46:46');
INSERT INTO `grades` VALUES('184','32','32','39','1','1','Sequence 1','14.25','Good','2026-05-27 04:32:05','2026-05-27 04:33:28');
INSERT INTO `grades` VALUES('186','28','46','39','1','1','Sequence 1','15','Bien','2026-05-27 04:50:54','2026-05-27 04:50:54');
INSERT INTO `grades` VALUES('187','28','46','39','1','2','Sequence 2','13.5','Assez Bien','2026-05-27 04:51:14','2026-05-27 04:51:14');
INSERT INTO `grades` VALUES('188','28','63','39','1','1','Sequence 1','12','Fairly Good','2026-05-27 05:24:49','2026-05-27 05:24:49');
INSERT INTO `grades` VALUES('190','28','63','39','1','2','Sequence 2','12.75','Fairly Good','2026-05-27 05:25:02','2026-05-27 05:25:02');

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `coefficient` int(11) DEFAULT 1,
  `establishment_id` int(11) DEFAULT NULL,
  `groupe` varchar(20) NOT NULL DEFAULT 'Groupe 1',
  `academic_year_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_subjects_establishment` (`establishment_id`),
  KEY `fk_subjects_academic_year` (`academic_year_id`),
  CONSTRAINT `fk_subjects_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `cycle_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `main_teacher_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nom` (`nom`),
  KEY `cycle_id` (`cycle_id`),
  KEY `section_id` (`section_id`),
  KEY `fk_main_teacher` (`main_teacher_id`),
  KEY `fk_classes_department` (`department_id`),
  KEY `idx_classes_establishment` (`establishment_id`),
  KEY `fk_classes_academic_year` (`academic_year_id`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`cycle_id`) REFERENCES `cycles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `classes_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_classes_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_classes_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_main_teacher` FOREIGN KEY (`main_teacher_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS = 1;

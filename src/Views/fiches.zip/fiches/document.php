<?php
$institution = $institution ?? [];
$activeYear = $activeYear ?? [];
$student = $student ?? [];
$rows = $rows ?? [];
$groupedRows = $groupedRows ?? [];
$classStats = $classStats ?? [];
$discipline = $discipline ?? [];
$rank = $rank ?? null;
$effectif = $effectif ?? 0;
$average = $average ?? null;
$mention = $mention ?? '';
$total_coefficients = $total_coefficients ?? 0;
$total_coef_valide = $total_coef_valide ?? 0;
$globalAppreciation = $globalAppreciation ?? '-';

$lang = \App\Core\Session::get('app_lang', 'fr');
$i = $institution;

// Récupération du logo via LogoManager pour affichage fiable
$db = \App\Core\Database::getInstance()->getConnection();
$logoManager = \App\Core\LogoManager::getInstance($db);
$logoData = [
    'has_logo' => $logoManager->hasLogo(),
    'base64' => $logoManager->hasLogo() ? $logoManager->getLogoBase64() : '',
    'url' => $logoManager->getLogoUrl(),
    'fallback_letter' => $logoManager->getFallbackLetter()
];
$contactLabels = [
    'bp' => __('bp'),
    'tel' => __('tel'),
    'fax' => __('fax'),
    'email' => __('email'),
    'web' => __('web')
];
$contact = trim($contactLabels['bp'] . ': ' . ($i['school_po_box'] ?? '') . ' | ' . $contactLabels['tel'] . ': ' . ($i['school_phone'] ?? '') . ' / ' . $contactLabels['fax'] . ': ' . ($i['school_fax'] ?? '') . ' | ' . $contactLabels['email'] . ': ' . ($i['school_email'] ?? '') . ' / ' . $contactLabels['web'] . ' : ' . ($i['school_website'] ?? ''));
$studentLastName = function_exists('mb_strtoupper') ? mb_strtoupper((string) ($student['nom'] ?? ''), 'UTF-8') : strtoupper((string) ($student['nom'] ?? ''));
$schoolDisplayName = function_exists('mb_strtoupper') ? mb_strtoupper((string) ($i['school_name'] ?? $i['school_code'] ?? ''), 'UTF-8') : strtoupper((string) ($i['school_name'] ?? $i['school_code'] ?? ''));
$schoolCodeWatermark = function_exists('mb_strtoupper') ? mb_strtoupper(trim((string) ($i['school_code'] ?? '')), 'UTF-8') : strtoupper(trim((string) ($i['school_code'] ?? '')));
$birthDate = $student['date_naissance'] ?? null;
$birthPlace = trim((string) ($student['lieu_naissance'] ?? ''));
$birthPlace = $birthPlace !== '' ? $birthPlace : '-';

$subjectCount = count($rows);
$baseFontSize = 9;
if ($subjectCount > 20) {
    $baseFontSize = 8;
}
if ($subjectCount > 25) {
    $baseFontSize = 7;
}

if (!function_exists('formatNote')) {
    function formatNote($val)
    {
        if ($val === null || $val === '-') {
            return '-';
        }
        $n = (float) $val;
        $fmt = number_format($n, 2, ',', ' ');
        if ($n >= 10) {
            return '<span class="vert">' . $fmt . '</span>';
        }
        return '<span class="rouge">' . $fmt . '</span>';
    }
}

if (!function_exists('formatSimple')) {
    function formatSimple($val)
    {
        if ($val === null || $val === '-') {
            return '-';
        }
        return number_format((float) $val, 2, ',', ' ');
    }
}

if (!function_exists('formatBulletinDate')) {
    function formatBulletinDate($val)
    {
        if ($val === null || $val === '') {
            return '-';
        }
        $timestamp = strtotime((string) $val);
        if ($timestamp === false) {
            return '-';
        }
        return date('d/m/Y', $timestamp);
    }
}

$evalTitle = '';
$evalSummaryLabel = __('total');
if (!empty($sequence)) {
    $evalTitle = $sequence['label'];
    if (preg_match('/SEQUENCE\s+(\d+)/i', (string) $evalTitle, $matches)) {
        $evalSummaryLabel = 'Seq ' . $matches[1];
    }
} elseif (!empty($term)) {
    $evalTitle = __('trimestre') . ' ' . $term;
    $evalSummaryLabel = __('trimester_short') . ' ' . $term;
} else {
    $evalTitle = __('annual');
    $evalSummaryLabel = __('annual_short');
}
$evalTitle = strtoupper($evalTitle);
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">

<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars((string) ($pdf_filename ?? 'Fiche-Notes')) ?></title>
    <style>
        @page {
            size: A4 portrait;
            margin: 0.5cm;
        }

        body {
            font-family: 'Arial', sans-serif;
            font-size:
                <?= $baseFontSize ?>
                px;
            margin: 0;
            padding: 0;
            color: #000;
            background: #fff;
        }

        .bulletin-sheet {
            width: 100%;
            margin: 0 auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin-bottom: 2px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 1px 3px;
            text-align: center;
            overflow: hidden;
        }

        th {
            background-color: #f2f2f2;
            text-transform: uppercase;
        }

        .left {
            text-align: left;
        }

        .bold {
            font-weight: bold;
        }

        .uppercase {
            text-transform: uppercase;
        }

        .vert {
            color: #008000;
        }

        .rouge {
            color: #ff0000;
        }

        .title-box {
            text-align: center;
            font-size: 14px;
            margin: 3px 0 2px;
            text-transform: uppercase;
            border: 2px solid #000;
            padding: 2px 3px;
        }

        .header-table td {
            border: none;
            padding: 0;
            vertical-align: top;
        }

        .header-line {
            font-size: 8px;
            font-weight: bold;
            margin: 0;
            text-transform: uppercase;
        }

        .logo-box {
            width: 82px;
            height: 82px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .logo-box img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            display: block;
        }

        .logo-placeholder {
            width: 82px;
            height: 82px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8px;
            font-weight: bold;
            letter-spacing: 1px;
            color: #8b97a3;
            line-height: 1.2;
            background: #f4f6f8;
            border-radius: 50%;
        }

        .school-name {
            font-weight: bold;
            font-size: 9px;
            margin-top: 3px;
            line-height: 1.15;
        }

        .grades-table-wrap {
            position: relative;
            margin-bottom: 2px;
        }

        .grades-watermark {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            text-align: center;
            padding-top: 150px;
            font-size: 18px;
            font-weight: 700;
            color: rgba(0, 0, 0, 0.05);
            letter-spacing: 2px;
            text-transform: uppercase;
            pointer-events: none;
            user-select: none;
            z-index: 0;
        }

        .grades-table {
            position: relative;
            z-index: 1;
        }

        .student-info-table td {
            border: 1px solid #000;
            text-align: left;
            padding: 2px 3px;
            font-size: 8px;
        }

        .nowrap {
            white-space: nowrap;
        }

        .grades-table th {
            font-size:
                <?= $baseFontSize ?>
                px;
        }

        .group-subtotal td {
            background-color: #e7f0fb;
            /* Fallback for Dompdf */
            background: linear-gradient(180deg, #e7f0fb 0%, #c9ddf4 100%);
            color: #17324d;
            font-weight: bold;
        }

        .teacher-name {
            font-size: 0.8em;
            text-transform: uppercase;
            display: block;
            margin-top: 1px;
        }

        .container-table {
            border: none;
            margin-bottom: 2px;
        }

        .container-table td {
            border: none;
            padding: 0;
            vertical-align: top;
        }

        .compact-layout {
            margin-bottom: 1px;
        }

        .compact-layout>tbody>tr>td {
            padding-right: 0;
        }

        .compact-layout>tbody>tr>td:last-child {
            padding-right: 0;
        }

        .side-table {
            width: 100%;
            border: 1px solid #000;
        }

        .side-table th {
            font-size:
                <?= $baseFontSize ?>
                px;
            border: 1px solid #000;
        }

        .side-table td {
            border: 1px solid #000;
            padding: 2px;
        }

        .compact-side {
            width: 100%;
            margin-bottom: 0;
        }

        .compact-side th,
        .compact-side td {
            padding: 1px 2px;
            line-height: 1.1;
        }

        .signature-table td {
            border: none;
            height: 48px;
            vertical-align: top;
            padding-top: 3px;
        }

        /* BARRE D'OUTILS */
        @media print {
            .pv-toolbar {
                display: none !important;
            }
        }

        .pv-toolbar {
            position: sticky;
            top: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background: #1a1a2e;
            color: white;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 15px;
            font-family: Arial, Helvetica, sans-serif;
        }

        .pv-toolbar-title {
            font-weight: bold;
            font-size: 13px;
            opacity: 0.9;
        }

        .pv-toolbar-hint {
            font-size: 10px;
            opacity: 0.6;
            margin-right: auto;
        }

        .pv-btn {
            padding: 7px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
            text-decoration: none;
            transition: opacity 0.2s;
            display: inline-block;
        }

        .pv-btn:hover {
            opacity: 0.85;
        }

        .pv-btn-print {
            background: #0d6efd;
            color: white;
        }

        .pv-btn-download {
            background: #198754;
            color: white;
            margin-left: 5px;
        }

        .pv-btn-back {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            margin-right: 5px;
        }

        @media screen and (max-width: 600px) {
            .pv-toolbar {
                flex-direction: column;
                align-items: stretch;
                gap: 8px;
            }

            .pv-btn {
                width: 100%;
                text-align: center;
                margin: 2px 0 !important;
            }
        }
    </style>
</head>

<body>
    <?php if (empty($isPdf)): ?>
        <!-- BARRE D'OUTILS (Non visible à l'impression) -->
        <div class="pv-toolbar">
            <div class="pv-toolbar-title">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"
                    style="vertical-align:-3px; margin-right:5px;">
                    <path
                        d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z" />
                    <path
                        d="M4.603 14.087a.81.81 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.68 7.68 0 0 1 1.482-.645 19.697 19.697 0 0 0 1.062-2.227 7.269 7.269 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .471.215c.15.18-.162 1.305-.162 1.305v.006c-.316.427-.58.111-.58.111s.54.407.728.846c.155.362.29.74.405 1.134.208.718.36 1.4.453 1.954.555.15 1.144.33 1.705.513.29.096.55.195.74.296.262.138.45.321.492.51.042.19.014.39-.115.546-.129.155-.327.24-.546.269-.219.03-.466-.02-.713-.102a4.954 4.954 0 0 1-1.396-.757c-.88-.705-1.58-1.748-1.9-2.235-.351.054-.7.108-1.049.157-.428.06-1.08.125-1.764.125-.453.03-.9.08-1.332.146-.356.055-.705.12-1.05.19-.24.049-.49.123-.715.22z" />
                </svg>
                Mode Impression & Export
            </div>
            <div class="pv-toolbar-hint">
                <?= __('pv_print_hint') ?>
            </div>
            <div>
                <a href="/fiches" class="pv-btn pv-btn-back">
                    &larr; <?= __('back') ?>
                </a>
                <button class="pv-btn pv-btn-print" onclick="window.print()">
                    <?= __('pv_print_btn') ?>
                </button>
                <a href="<?= $_SERVER['REQUEST_URI'] . (strpos($_SERVER['REQUEST_URI'], '?') === false ? '?' : '&') ?>format=pdf"
                    class="pv-btn pv-btn-download" target="_blank">
                    <i class="bi bi-download"></i> <?= __('download_pdf') ?>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <div class="bulletin-sheet">
        <table class="header-table">
            <tr>
                <td width="35%" style="text-align: center;">
                    <p class="header-line">
                        <?= htmlspecialchars((string) ($i['school_republic'] ?? __('republic_of_cameroon'))) ?></p>
                    <p class="header-line"><?= htmlspecialchars((string) ($i['school_motto'] ?? __('motto'))) ?></p>
                    <p class="header-line">
                        <?= htmlspecialchars((string) ($i['school_ministry'] ?? __('ministry_secondary_education'))) ?>
                    </p>
                    <p class="header-line"><?= htmlspecialchars((string) ($i['school_slogan'] ?? __('slogan'))) ?></p>
                    <p style="font-size: 7px; margin: 2px 0;"><?= htmlspecialchars(strtoupper($contact)) ?></p>
                </td>
                <td width="30%" style="text-align: center;">
                    <div class="logo-box">
                        <?php if ($logoData['has_logo'] && !empty($logoData['base64'])): ?>
                            <img src="<?= htmlspecialchars($logoData['base64']) ?>" alt="<?= __('school_logo_alt') ?>">
                        <?php elseif ($logoData['has_logo'] && !empty($logoData['url'])): ?>
                            <img src="<?= htmlspecialchars($logoData['url']) ?>" alt="<?= __('school_logo_alt') ?>">
                        <?php else: ?>
                            <div class="logo-placeholder"><?= htmlspecialchars($logoData['fallback_letter']) ?></div>
                        <?php endif; ?>
                    </div>
                    <p class="school-name"><?= htmlspecialchars($schoolDisplayName) ?></p>
                </td>
                <td width="35%" style="text-align: center;">
                    <p class="header-line">
                        <?= htmlspecialchars((string) ($i['school_republic_en'] ?? 'REPUBLIC OF CAMEROON')) ?></p>
                    <p class="header-line">
                        <?= htmlspecialchars((string) ($i['school_motto_en'] ?? 'PEACE - WORK - FATHERLAND')) ?></p>
                    <p class="header-line">
                        <?= htmlspecialchars((string) ($i['school_ministry_en'] ?? 'MINISTRY OF SECONDARY EDUCATION')) ?>
                    </p>
                    <p class="header-line">
                        <?= htmlspecialchars((string) ($i['school_slogan_en'] ?? 'DISCIPLINE - WORK - SUCCESS')) ?></p>
                    <p style="font-size: 7px; margin: 2px 0;"><?= htmlspecialchars(strtoupper($contact)) ?></p>
                </td>
            </tr>
        </table>

        <div class="title-box" style="font-weight: bold;"><?= __('fiche_report_card') ?> -
            <?= htmlspecialchars($evalTitle) ?></div>

        <table class="student-info-table">
            <tr>
                <td colspan="2" class="nowrap"><?= __('name_and_surname') ?> : <span class="uppercase"
                        style="font-weight: 600;"><?= htmlspecialchars($studentLastName . ' ' . ($student['prenom'] ?? '')) ?></span>
                </td>
                <td class="nowrap"><?= __('matricule') ?> : <span
                        style="font-weight: 600;"><?= htmlspecialchars((string) ($displayMatricule ?? $student['matricule'] ?? '')) ?></span>
                </td>
                <td class="nowrap"><?= __('class') ?> : <span
                        style="font-weight: 600;"><?= htmlspecialchars((string) ($student['class_nom'] ?? '')) ?></span>
                </td>
                <td class="nowrap"><?= __('sex') ?> : <span
                        style="font-weight: 600;"><?= htmlspecialchars((string) ($student['sexe'] ?? '-')) ?></span>
                </td>
                <td class="nowrap"><?= __('year') ?> : <span
                        style="font-weight: 600;"><?= htmlspecialchars((string) ($activeYear['nom'] ?? '')) ?></span>
                </td>
            </tr>
            <tr>
                <td class="nowrap"><?= __('birth_date') ?> : <span
                        style="font-weight: 600;"><?= htmlspecialchars(formatBulletinDate($birthDate)) ?></span></td>
                <td colspan="4" class="nowrap"><?= __('birth_place') ?> : <span
                        style="font-weight: 600;"><?= htmlspecialchars($birthPlace) ?></span></td>
                <td class="nowrap"><?= __('effectif') ?> : <span style="font-weight: 600;"><?= (int) $effectif ?></span>
                </td>
            </tr>
        </table>

        <div class="grades-table-wrap">
            <div class="grades-watermark"><?= htmlspecialchars($schoolCodeWatermark) ?></div>
            <table class="grades-table">
                <thead>
                    <tr>
                        <th width="30%"><?= __('subject') ?></th>
                        <th width="12%"><?= __('average') ?></th>
                        <th width="6%"><?= __('coef') ?></th>
                        <th width="10%"><?= __('weighted_mark') ?></th>
                        <th width="10%"><?= __('class_avg') ?></th>
                        <th width="8%"><?= __('rank') ?></th>
                        <th width="24%"><?= __('appreciation') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($groupedRows as $group): ?>
                        <?php foreach ($group['rows'] as $row): ?>
                            <tr>
                                <td class="left">
                                    <div><?= htmlspecialchars($row['subject']) ?></div>
                                    <span class="teacher-name"><?= htmlspecialchars($row['teacher']) ?></span>
                                </td>
                                <td><?= isset($row['note']) ? formatNote($row['note']) : (isset($row['average']) ? formatNote($row['average']) : '-') ?>
                                </td>
                                <td><?= (int) ($row['coefficient'] ?? 1) ?></td>
                                <td><?= isset($row['weighted']) ? formatNote($row['weighted']) : '-' ?></td>
                                <td><?= isset($row['class_average_subject']) ? formatSimple($row['class_average_subject']) : '-' ?>
                                </td>
                                <td><?= $row['rank_subject'] ?? '-' ?></td>
                                <td><?= htmlspecialchars($row['appreciation'] ?? '-') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php
                        $groupEvaluationTotal = 0.0;
                        $groupHasEvaluationTotal = false;
                        foreach ($group['rows'] as $groupRow) {
                            $note = $groupRow['note'] ?? $groupRow['average'] ?? null;
                            if ($note !== null) {
                                $groupEvaluationTotal += (float) $note;
                                $groupHasEvaluationTotal = true;
                            }
                        }
                        ?>
                        <tr class="group-subtotal">
                            <td class="left"><?= htmlspecialchars($group['label']) ?></td>
                            <td><?= htmlspecialchars($evalSummaryLabel) ?>:
                                <?= $groupHasEvaluationTotal ? formatSimple($groupEvaluationTotal) : '-' ?></td>
                            <td><?= (int) ($group['total_coefficients'] ?? 0) ?></td>
                            <td><?= strtoupper(__('total')) ?>: <?= formatSimple($group['total_points'] ?? 0) ?></td>
                            <td colspan="3"></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <table class="container-table compact-layout">
            <tr>
                <td width="33%">
                    <table class="side-table compact-side">
                        <tr>
                            <th colspan="2"><?= __('class_stats') ?></th>
                        </tr>
                        <tr>
                            <td class="left"><?= __('class_avg_gen') ?></td>
                            <td><?= formatSimple($classStats['average'] ?? null) ?></td>
                        </tr>
                        <tr>
                            <td class="left"><?= __('note_max') ?></td>
                            <td><?= formatSimple($classStats['max'] ?? null) ?></td>
                        </tr>
                        <tr>
                            <td class="left"><?= __('note_min') ?></td>
                            <td><?= formatSimple($classStats['min'] ?? null) ?></td>
                        </tr>
                        <tr>
                            <td class="left"><?= __('total_coeff_passed') ?></td>
                            <td><?= (int) $total_coef_valide ?> / <?= (int) $total_coefficients ?></td>
                        </tr>
                    </table>
                </td>
                <td width="33%">
                    <table class="side-table compact-side">
                        <tr>
                            <th colspan="2"><?= __('student_summary') ?></th>
                        </tr>
                        <tr>
                            <td class="left"><?= __('student_avg') ?></td>
                            <td style="font-size: 11px; font-weight: bold;"><?= formatNote($average) ?></td>
                        </tr>
                        <tr>
                            <td class="left"><?= __('student_rank') ?></td>
                            <td style="font-weight: bold;"><?= $rank !== null ? $rank . ' / ' . $effectif : '-' ?></td>
                        </tr>
                        <tr>
                            <td class="left"><?= __('mention') ?></td>
                            <td class="uppercase"><?= htmlspecialchars($mention) ?></td>
                        </tr>
                    </table>
                </td>
                <td width="33%">
                    <table class="side-table compact-side">
                        <tr>
                            <th colspan="2"><?= __('general_observation') ?></th>
                        </tr>
                        <tr>
                            <td class="left"><?= __('period') ?></td>
                            <td><?= htmlspecialchars($evalTitle) ?></td>
                        </tr>
                        <tr>
                            <td class="left"><?= __('appreciation') ?></td>
                            <td class="left uppercase bold"><?= htmlspecialchars($globalAppreciation) ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>

        <table class="signature-table" style="margin-top: 20px;">
            <tr>
                <td width="33%"><?= __('signature_student_parent') ?></td>
                <td width="33%" style="text-align: center;"><?= __('signature_teacher') ?></td>
                <td width="33%" style="text-align: right;"><?= __('pv_sig_principal') ?></td>
            </tr>
            <tr>
                <td></td>
                <td style="text-align: center;"><strong><?= htmlspecialchars($professor_name ?? '') ?></strong></td>
                <td style="text-align: right;"></td>
            </tr>
        </table>
    </div>
</body>

</html>